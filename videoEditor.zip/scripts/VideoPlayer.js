var hello = true;

function VideoPlayer(id)
{
	var vp = this;

	this.startPoint = -1;
	this.endPoint = -1;

	this.label = document.querySelector(id + " .playerLabel");
	this.video = document.querySelector(id + " video");

	this.buttons = document.querySelectorAll(id + " .buttonGroup button");
	
	this.buttons[2].onclick = function() {  vp.setSpeed(-5.0); };
	this.buttons[3].onclick = function() 
	{ 
		vp.video.pause();
		vp.video.currentTime = 0; 
	};
	this.buttons[4].onclick = function() {  vp.setSpeed(-2.0); };
	this.buttons[5].onclick = function()
	{
		var img = this.querySelector("IMG");
		if(img.src.indexOf("play") != -1)
		{
			vp.video.play();

			vp.overlay.innerHTML = "";
			
			this.title = "Pause";
			img.src = "buttons/pause.png";
		}
		else
		{
			vp.overlay.innerHTML = "Paused";

			vp.video.pause();
			this.title = "Play";
		}
	};
	this.buttons[6].onclick = function() {  vp.setSpeed(2.0); };
	this.buttons[7].onclick = function() 
	{ 
		vp.video.pause();
		vp.video.currentTime = vp.video.duration; 
	};
	this.buttons[8].onclick = function() {  vp.setSpeed(5.0); };

	this.progressBar = document.querySelector(id + " .progressBar");

	this.timeLabel = document.querySelector(id + " .timeLabel");
	this.fileLabel = document.querySelector(id + " .fileLabel");	
	this.overlay = document.querySelector(id + " .videoOverlay");
	
	this.update = function()
	{
		var percentage = Math.floor((100 / vp.video.duration) *  vp.video.currentTime);
		vp.progressBar.style.width = percentage + "%";

		vp.timeLabel.innerHTML = toHHMMSS(vp.video.currentTime);
	};

	this.setSpeed = function(s)
	{
		vp.video.playbackRate = s; 
		vp.overlay.innerHTML = (s == 1.0 ? "" : s + "x");	
	};

	this.setStartPoint = function(tb)
	{
		vp.startTime = -1;

		var t = tb.value.split(":");
		if(t.length != 3)
		{
			alert("Please enter a valid time.");
			tb.value = "00:00:00";
			return;
		}
		else
		{
			var sec = (parseInt(t[0], 10) * 60 * 60) + (parseInt(t[1], 10) * 60) + parseInt(t[2]);
			
			if(sec > vp.video.duration)
			{
				alert("That is not a valid start time.");
				tb.value = "00:00:00";
				return;
			}
			else
			{
				vp.video.currentTime = sec;
				vp.startTime = sec;
			}
		}
	};

	this.setEndPoint = function(tb)
	{
		vp.endTime = -1;

		var t = tb.value.split(":");
		if(t.length != 3)
		{
			alert("Please enter a valid time.");
			tb.value = "00:00:00";
			return;
		}
		else
		{
			var sec = (parseInt(t[0], 10) * 60 * 60) + (parseInt(t[1], 10) * 60) + parseInt(t[2]);
			
			if(sec > vp.video.duration)
			{
				alert("That is not a valid end time.");
				tb.value = "00:00:00";
				return;
			}
			else
			{
				vp.endTime = sec;
			}
		}
	};

	this.flipH = function() { vp.video.classList.toggle("flipH"); };
	this.flipV = function() { vp.video.classList.toggle("flipV"); };
	this.rotate90Left = function() { vp.video.classList.toggle("rotate90Left"); };
	this.rotate90Right = function() { vp.video.classList.toggle("rotate90Right"); };

	this.setBrightness = function(value) { vp.video.style.filter = "brightness(" + value + "%)"; };
	this.setContrast = function(value) { vp.video.style.filter = "contrast(" + value + "%)"; };
	this.setHue = function(value) { vp.video.style.filter = "hue-rotate(" + value + "deg)"; };
	this.setSaturation = function(value) { vp.video.style.filter = "saturate(" + value + "%)"; };

	this.applyFilter = function(f)
	{
		var url = (f == "" ? "none" : "url(" + f + ")");

		vp.video.style.webkitFilter = url;
		vp.video.style.mozFilter = url;
		vp.video.style.filter = url;
	};

	this.video.ontimeupdate = this.update;
	this.video.onpause = function() { vp.buttons[5].querySelector("IMG").src = "buttons/play.png"; };
	this.video.onplaying = function()
	{
		if(vp.startTime != -1 && this.currentTime < vp.startTime) 
		{
			this.currentTime = vp.startTime;
		}
	};
}